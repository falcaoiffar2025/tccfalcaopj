<?php

function validarCPF($cpf) {
    $cpf = preg_replace('/\D/', '', $cpf);
    if (strlen($cpf) != 11 || preg_match('/^(\d)\1{10}$/', $cpf)) return false;

    for ($t = 9; $t < 11; $t++) {
        $soma = 0;
        for ($i = 0; $i < $t; $i++) {
            $soma += $cpf[$i] * (($t + 1) - $i);
        }
        $digito = (10 * $soma) % 11 % 10;
        if ($cpf[$t] != $digito) return false;
    }

    return true;
}

function validarTelefone($telefone) {
    $telefone = preg_replace('/\D/', '', $telefone);
    return preg_match('/^\d{10,11}$/', $telefone);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dados = [
        'nome_banca' => $_POST['nome_banca'],
        'responsavel' => $_POST['responsavel'],
        'telefone' => $_POST['telefone'],
        'email' => $_POST['email'],
        'cpf' => $_POST['cpf'],
        'senha' => $_POST['senha'],
        'categoria' => $_POST['categoria'],
        'descricao' => $_POST['descricao'],
    ];

    foreach (['nome_banca', 'responsavel', 'telefone', 'email', 'cpf', 'senha'] as $campo) {
        if (empty($dados[$campo])) {
            exit("Erro: Todos os campos obrigatórios devem ser preenchidos.");
        }
    }

    if (!validarTelefone($dados['telefone'])) exit("Erro: Telefone inválido.");
    if (!filter_var($dados['email'], FILTER_VALIDATE_EMAIL)) exit("Erro: E-mail inválido.");
    if (!validarCPF($dados['cpf'])) exit("Erro: CPF inválido.");
    if (strlen($dados['senha']) < 8) exit("Erro: A senha deve ter no mínimo 8 caracteres.");

    ?>
    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>Cadastro realizado</title>
        <style>
            body { font-family: Arial, sans-serif; background: #f0f0f0; padding: 20px; }
            .container { max-width: 600px; margin: auto; background: #fff; padding: 20px; border-radius: 8px; }
            h1 { color: #006d77; }
            .btn { margin-top: 20px; display: inline-block; background: #ee6c4d; color: #fff; padding: 10px 15px; border-radius: 5px; text-decoration: none; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Cadastro realizado com sucesso!</h1>
            <?php foreach ([
                'nome_banca' => 'Nome da Banca/Loja',
                'responsavel' => 'Responsável',
                'telefone' => 'Telefone/WhatsApp',
                'email' => 'E-mail',
                'cpf' => 'CPF',
                'categoria' => 'Categoria',
                'descricao' => 'Descrição'
            ] as $campo => $rotulo): ?>
                <p><strong><?= $rotulo ?>:</strong> <?= nl2br($dados[$campo]) ?></p>
            <?php endforeach; ?>
            <a class="btn" href="index.html">Voltar para o site</a>
        </div>
    </body>
    </html>
    <?php
} else {
    header('Location: index.html');
    exit;
}
?>
