// ---------------- SLIDER DE BANCAS ---------------- //

const bancasContainer = document.getElementById('bancasContainer');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');

let scrollAmount = 0;
const scrollStep = 300; // Define o quanto o slider deve se mover

prevBtn.addEventListener('click', () => {
    scrollAmount -= scrollStep;
    if (scrollAmount < 0) scrollAmount = 0; // Impede que o slider vá além do início
    bancasContainer.style.transform = `translateX(-${scrollAmount}px)`;
});

nextBtn.addEventListener('click', () => {
    scrollAmount += scrollStep;
    const maxScroll = bancasContainer.scrollWidth - bancasContainer.clientWidth; // Calcula o limite máximo de scroll
    if (scrollAmount > maxScroll) scrollAmount = maxScroll; // Impede que o slider vá além do final
    bancasContainer.style.transform = `translateX(-${scrollAmount}px)`;
});